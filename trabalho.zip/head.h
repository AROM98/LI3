#define _GNU_SOURCE
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

//ficheiro a ser usado para defenir esturuturas de dados.
//stacks ou heaps?

void validvendas();
void clienttoArray();
void prodtoArray();
